using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Wiggler
{
    internal static class Program
    {
        [STAThread]
        private static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new WigglerTrayContext());
        }
    }

    internal sealed class WigglerTrayContext : ApplicationContext
    {
        private const int KeyUpFlag = 0x0002;
        private readonly Dictionary<string, KeyConfig> availableKeys;
        private readonly Timer loopTimer;
        private readonly NotifyIcon trayIcon;
        private readonly ToolStripMenuItem startMenuItem;
        private readonly ToolStripMenuItem stopMenuItem;
        private readonly ToolStripMenuItem keyMenuItem;
        private readonly Icon activeIcon;
        private readonly Icon inactiveIcon;
        private KeyConfig selectedKey;
        private bool isRunning;
        private LoopPhase nextPhase;

        public WigglerTrayContext()
        {
            availableKeys = BuildKeyMap();
            selectedKey = availableKeys["NUM"];
            nextPhase = LoopPhase.FirstToggle;

            activeIcon = LoadTrayIcon("ON_icon.png");
            inactiveIcon = LoadTrayIcon("OFF_icon.png");

            loopTimer = new Timer();
            loopTimer.Tick += OnLoopTimerTick;

            startMenuItem = new ToolStripMenuItem("Start");
            startMenuItem.Click += (sender, eventArgs) => StartLoop();

            stopMenuItem = new ToolStripMenuItem("Stop");
            stopMenuItem.Click += (sender, eventArgs) => StopLoop();

            keyMenuItem = new ToolStripMenuItem("Select Key");
            BuildKeySelectionMenu();

            var exitMenuItem = new ToolStripMenuItem("Exit");
            exitMenuItem.Click += (sender, eventArgs) => ExitApplication();

            trayIcon = new NotifyIcon
            {
                Text = "wiggler",
                Visible = true,
                ContextMenuStrip = new ContextMenuStrip()
            };

            trayIcon.ContextMenuStrip.Items.Add(startMenuItem);
            trayIcon.ContextMenuStrip.Items.Add(stopMenuItem);
            trayIcon.ContextMenuStrip.Items.Add(keyMenuItem);
            trayIcon.ContextMenuStrip.Items.Add(new ToolStripSeparator());
            trayIcon.ContextMenuStrip.Items.Add(exitMenuItem);
            trayIcon.DoubleClick += (sender, eventArgs) => ToggleLoop();

            UpdateUiState();
        }

        private void BuildKeySelectionMenu()
        {
            foreach (var entry in availableKeys)
            {
                var keyName = entry.Key;
                var menuItem = new ToolStripMenuItem(keyName)
                {
                    CheckOnClick = true,
                    Tag = entry.Value
                };

                menuItem.Click += (sender, eventArgs) => SelectKey(keyName);
                keyMenuItem.DropDownItems.Add(menuItem);
            }
        }

        private void SelectKey(string keyName)
        {
            if (isRunning || !availableKeys.ContainsKey(keyName))
            {
                return;
            }

            selectedKey = availableKeys[keyName];

            foreach (ToolStripMenuItem menuItem in keyMenuItem.DropDownItems)
            {
                menuItem.Checked = string.Equals(menuItem.Text, keyName, StringComparison.Ordinal);
            }
        }

        private void ToggleLoop()
        {
            if (isRunning)
            {
                StopLoop();
                return;
            }

            StartLoop();
        }

        private void StartLoop()
        {
            if (isRunning)
            {
                return;
            }

            isRunning = true;
            nextPhase = LoopPhase.SecondToggle;

            // Send the first key press immediately so the user sees the effect right away.
            SendKeyPress(selectedKey);
            loopTimer.Interval = 1000;
            loopTimer.Start();

            UpdateUiState();
        }

        private void StopLoop()
        {
            loopTimer.Stop();
            isRunning = false;
            nextPhase = LoopPhase.FirstToggle;

            UpdateUiState();
        }

        private void OnLoopTimerTick(object sender, EventArgs e)
        {
            if (!isRunning)
            {
                return;
            }

            SendKeyPress(selectedKey);

            if (nextPhase == LoopPhase.SecondToggle)
            {
                nextPhase = LoopPhase.FirstToggle;
                loopTimer.Interval = 20000;
                return;
            }

            nextPhase = LoopPhase.SecondToggle;
            loopTimer.Interval = 1000;
        }

        private void UpdateUiState()
        {
            startMenuItem.Enabled = !isRunning;
            stopMenuItem.Enabled = isRunning;
            keyMenuItem.Enabled = !isRunning;
            trayIcon.Icon = isRunning ? activeIcon : inactiveIcon;
            trayIcon.Text = isRunning
                ? string.Format("wiggler - Running ({0})", selectedKey.Name)
                : string.Format("wiggler - Stopped ({0})", selectedKey.Name);

            SelectKey(selectedKey.Name);
        }

        private static Dictionary<string, KeyConfig> BuildKeyMap()
        {
            return new Dictionary<string, KeyConfig>(StringComparer.Ordinal)
            {
                { "NUM", new KeyConfig("NUM", 0x90, 0x45) },
                { "ESC", new KeyConfig("ESC", 0x1B, 0x01) },
                { "SPACE", new KeyConfig("SPACE", 0x20, 0x39) },
                { "ALT", new KeyConfig("ALT", 0x12, 0x38) },
                { "STRG", new KeyConfig("STRG", 0x11, 0x1D) },
                { "F1", new KeyConfig("F1", 0x70, 0x3B) },
                { "F2", new KeyConfig("F2", 0x71, 0x3C) },
                { "F3", new KeyConfig("F3", 0x72, 0x3D) },
                { "F4", new KeyConfig("F4", 0x73, 0x3E) },
                { "F5", new KeyConfig("F5", 0x74, 0x3F) },
                { "F6", new KeyConfig("F6", 0x75, 0x40) },
                { "F7", new KeyConfig("F7", 0x76, 0x41) },
                { "F8", new KeyConfig("F8", 0x77, 0x42) },
                { "F9", new KeyConfig("F9", 0x78, 0x43) },
                { "F10", new KeyConfig("F10", 0x79, 0x44) },
                { "F11", new KeyConfig("F11", 0x7A, 0x57) },
                { "F12", new KeyConfig("F12", 0x7B, 0x58) }
            };
        }

        private static void SendKeyPress(KeyConfig keyConfig)
        {
            NativeMethods.keybd_event(keyConfig.VirtualKey, keyConfig.ScanCode, 0, UIntPtr.Zero);
            System.Threading.Thread.Sleep(50);
            NativeMethods.keybd_event(keyConfig.VirtualKey, keyConfig.ScanCode, KeyUpFlag, UIntPtr.Zero);
        }

        private static Icon LoadTrayIcon(string fileName)
        {
            var iconPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "icons", fileName);

            if (!File.Exists(iconPath))
            {
                return SystemIcons.Application;
            }

            using (var bitmap = new Bitmap(iconPath))
            {
                var iconHandle = bitmap.GetHicon();

                try
                {
                    // Clone the icon so the bitmap handle can be released safely afterwards.
                    return (Icon)Icon.FromHandle(iconHandle).Clone();
                }
                finally
                {
                    NativeMethods.DestroyIcon(iconHandle);
                }
            }
        }

        private void ExitApplication()
        {
            StopLoop();
            trayIcon.Visible = false;
            ExitThread();
        }

        protected override void ExitThreadCore()
        {
            trayIcon.Dispose();
            loopTimer.Dispose();
            activeIcon.Dispose();
            inactiveIcon.Dispose();
            base.ExitThreadCore();
        }

        private enum LoopPhase
        {
            FirstToggle,
            SecondToggle
        }
    }

    internal sealed class KeyConfig
    {
        private readonly string name;
        private readonly byte virtualKey;
        private readonly byte scanCode;

        public KeyConfig(string name, byte virtualKey, byte scanCode)
        {
            this.name = name;
            this.virtualKey = virtualKey;
            this.scanCode = scanCode;
        }

        public string Name
        {
            get { return name; }
        }

        public byte VirtualKey
        {
            get { return virtualKey; }
        }

        public byte ScanCode
        {
            get { return scanCode; }
        }
    }

    internal static class NativeMethods
    {
        [DllImport("user32.dll", SetLastError = true)]
        public static extern void keybd_event(byte bVk, byte bScan, int dwFlags, UIntPtr dwExtraInfo);

        [DllImport("user32.dll", SetLastError = true)]
        public static extern bool DestroyIcon(IntPtr hIcon);
    }
}
