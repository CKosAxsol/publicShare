param(
    [switch]$BuildOnly
)

$projectRoot = Split-Path -Parent $PSScriptRoot
$exePath = Join-Path $projectRoot 'wiggler.exe'
$buildScriptPath = Join-Path $PSScriptRoot 'build-wiggler.ps1'

if (-not (Test-Path $exePath)) {
    & $buildScriptPath
}

if ($BuildOnly) {
    return
}

Start-Process -FilePath $exePath -WorkingDirectory $projectRoot -WindowStyle Hidden
