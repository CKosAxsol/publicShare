param(
    [switch]$Launch
)

$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$sourcePath = Join-Path $PSScriptRoot 'WigglerTrayApp.cs'
$outputPath = Join-Path $projectRoot 'wiggler.exe'

if (-not (Test-Path $sourcePath)) {
    throw "Source file not found: $sourcePath"
}

if (Test-Path $outputPath) {
    Remove-Item -LiteralPath $outputPath -Force
}

# This compiles the tray application with built-in .NET assemblies so no extra packages are needed.
Add-Type `
    -TypeDefinition (Get-Content -LiteralPath $sourcePath -Raw) `
    -ReferencedAssemblies @('System.dll', 'System.Drawing.dll', 'System.Windows.Forms.dll') `
    -OutputAssembly $outputPath `
    -OutputType WindowsApplication

Write-Host "Created $outputPath"

if ($Launch) {
    Start-Process -FilePath $outputPath -WorkingDirectory $projectRoot -WindowStyle Hidden
}
