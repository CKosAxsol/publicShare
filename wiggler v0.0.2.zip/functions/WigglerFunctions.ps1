function Set-WigglerStatus {
    param(
        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Label]$StatusLabel,

        [Parameter(Mandatory = $true)]
        [bool]$IsRunning
    )

    if ($IsRunning) {
        $StatusLabel.Text = 'Running'
        $StatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(0, 120, 0)
        return
    }

    $StatusLabel.Text = 'Stopped'
    $StatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(160, 0, 0)
}

function Get-WigglerKeyMap {
    $keyMap = [ordered]@{
        'NUM'   = @{ VirtualKey = 0x90; ScanCode = 0x45 }
        'ESC'   = @{ VirtualKey = 0x1B; ScanCode = 0x01 }
        'SPACE' = @{ VirtualKey = 0x20; ScanCode = 0x39 }
        'ALT'   = @{ VirtualKey = 0x12; ScanCode = 0x38 }
        'STRG'  = @{ VirtualKey = 0x11; ScanCode = 0x1D }
        'F1'    = @{ VirtualKey = 0x70; ScanCode = 0x3B }
        'F2'    = @{ VirtualKey = 0x71; ScanCode = 0x3C }
        'F3'    = @{ VirtualKey = 0x72; ScanCode = 0x3D }
        'F4'    = @{ VirtualKey = 0x73; ScanCode = 0x3E }
        'F5'    = @{ VirtualKey = 0x74; ScanCode = 0x3F }
        'F6'    = @{ VirtualKey = 0x75; ScanCode = 0x40 }
        'F7'    = @{ VirtualKey = 0x76; ScanCode = 0x41 }
        'F8'    = @{ VirtualKey = 0x77; ScanCode = 0x42 }
        'F9'    = @{ VirtualKey = 0x78; ScanCode = 0x43 }
        'F10'   = @{ VirtualKey = 0x79; ScanCode = 0x44 }
        'F11'   = @{ VirtualKey = 0x7A; ScanCode = 0x57 }
        'F12'   = @{ VirtualKey = 0x7B; ScanCode = 0x58 }
    }

    return $keyMap
}

function Update-WigglerButtons {
    param(
        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Button]$StartButton,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Button]$StopButton,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.ComboBox]$KeySelector,

        [Parameter(Mandatory = $true)]
        [bool]$IsRunning
    )

    $StartButton.Enabled = -not $IsRunning
    $StopButton.Enabled = $IsRunning
    $KeySelector.Enabled = -not $IsRunning
}

function Send-WigglerKeyPress {
    param(
        [Parameter(Mandatory = $true)]
        [Type]$KeyboardApi,

        [Parameter(Mandatory = $true)]
        [hashtable]$KeyConfig
    )

    # This uses the native Windows keyboard API so the selected key is sent globally.
    $keyUpFlag = 0x0002

    $KeyboardApi::keybd_event($KeyConfig.VirtualKey, $KeyConfig.ScanCode, 0, [UIntPtr]::Zero)
    Start-Sleep -Milliseconds 50
    $KeyboardApi::keybd_event($KeyConfig.VirtualKey, $KeyConfig.ScanCode, $keyUpFlag, [UIntPtr]::Zero)
}

function Start-WigglerLoop {
    param(
        [Parameter(Mandatory = $true)]
        [Type]$KeyboardApi,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Timer]$Timer,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Label]$StatusLabel,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Button]$StartButton,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Button]$StopButton,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.ComboBox]$KeySelector
    )

    if ($script:IsRunning) {
        return
    }

    $selectedKeyName = [string]$KeySelector.SelectedItem
    $availableKeys = Get-WigglerKeyMap

    if (-not $availableKeys.Contains($selectedKeyName)) {
        throw "Unsupported key selection: $selectedKeyName"
    }

    $script:IsRunning = $true
    $script:NextPhase = 'SecondToggle'
    $script:SelectedKeyConfig = $availableKeys[$selectedKeyName]

    Set-WigglerStatus -StatusLabel $StatusLabel -IsRunning $true
    Update-WigglerButtons -StartButton $StartButton -StopButton $StopButton -KeySelector $KeySelector -IsRunning $true

    # The first key press happens immediately so the app reacts as soon as the user starts it.
    Send-WigglerKeyPress -KeyboardApi $KeyboardApi -KeyConfig $script:SelectedKeyConfig
    $Timer.Interval = 1000
    $Timer.Start()
}

function Stop-WigglerLoop {
    param(
        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Timer]$Timer,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Label]$StatusLabel,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Button]$StartButton,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Button]$StopButton,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.ComboBox]$KeySelector
    )

    $Timer.Stop()
    $script:IsRunning = $false
    $script:NextPhase = 'FirstToggle'
    $script:SelectedKeyConfig = $null

    Set-WigglerStatus -StatusLabel $StatusLabel -IsRunning $false
    Update-WigglerButtons -StartButton $StartButton -StopButton $StopButton -KeySelector $KeySelector -IsRunning $false
}

function Step-WigglerLoop {
    param(
        [Parameter(Mandatory = $true)]
        [Type]$KeyboardApi,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Timer]$Timer
    )

    if (-not $script:IsRunning) {
        return
    }

    if ($script:NextPhase -eq 'SecondToggle') {
        # This mirrors the original one-second pause before the second key press.
        Send-WigglerKeyPress -KeyboardApi $KeyboardApi -KeyConfig $script:SelectedKeyConfig
        $script:NextPhase = 'FirstToggle'
        $Timer.Interval = 20000
        return
    }

    # This starts the next cycle after the longer wait from the original script.
    Send-WigglerKeyPress -KeyboardApi $KeyboardApi -KeyConfig $script:SelectedKeyConfig
    $script:NextPhase = 'SecondToggle'
    $Timer.Interval = 1000
}
