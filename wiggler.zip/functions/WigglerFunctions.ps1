function Set-WigglerStatus {
    param(
        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Label]$StatusLabel,

        [Parameter(Mandatory = $true)]
        [bool]$IsRunning
    )

    if ($IsRunning) {
        $StatusLabel.Text = 'Running'
        $StatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(0, 120, 0)
        return
    }

    $StatusLabel.Text = 'Stopped'
    $StatusLabel.ForeColor = [System.Drawing.Color]::FromArgb(160, 0, 0)
}

function Update-WigglerButtons {
    param(
        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Button]$StartButton,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Button]$StopButton,

        [Parameter(Mandatory = $true)]
        [bool]$IsRunning
    )

    $StartButton.Enabled = -not $IsRunning
    $StopButton.Enabled = $IsRunning
}

function Send-WigglerToggle {
    param(
        [Parameter(Mandatory = $true)]
        [Type]$KeyboardApi
    )

    # This uses the native Windows keyboard API so the key event is sent globally.
    $virtualKeyNumLock = 0x90
    $keyUpFlag = 0x0002

    $KeyboardApi::keybd_event($virtualKeyNumLock, 0x45, 0, [UIntPtr]::Zero)
    Start-Sleep -Milliseconds 50
    $KeyboardApi::keybd_event($virtualKeyNumLock, 0x45, $keyUpFlag, [UIntPtr]::Zero)
}

function Start-WigglerLoop {
    param(
        [Parameter(Mandatory = $true)]
        [Type]$KeyboardApi,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Timer]$Timer,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Label]$StatusLabel,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Button]$StartButton,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Button]$StopButton
    )

    if ($script:IsRunning) {
        return
    }

    $script:IsRunning = $true
    $script:NextPhase = 'SecondToggle'

    Set-WigglerStatus -StatusLabel $StatusLabel -IsRunning $true
    Update-WigglerButtons -StartButton $StartButton -StopButton $StopButton -IsRunning $true

    # The first key press happens immediately so the app reacts as soon as the user starts it.
    Send-WigglerToggle -KeyboardApi $KeyboardApi
    $Timer.Interval = 1000
    $Timer.Start()
}

function Stop-WigglerLoop {
    param(
        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Timer]$Timer,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Label]$StatusLabel,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Button]$StartButton,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Button]$StopButton
    )

    $Timer.Stop()
    $script:IsRunning = $false
    $script:NextPhase = 'FirstToggle'

    Set-WigglerStatus -StatusLabel $StatusLabel -IsRunning $false
    Update-WigglerButtons -StartButton $StartButton -StopButton $StopButton -IsRunning $false
}

function Step-WigglerLoop {
    param(
        [Parameter(Mandatory = $true)]
        [Type]$KeyboardApi,

        [Parameter(Mandatory = $true)]
        [System.Windows.Forms.Timer]$Timer
    )

    if (-not $script:IsRunning) {
        return
    }

    if ($script:NextPhase -eq 'SecondToggle') {
        # This mirrors the original one-second pause before the second key press.
        Send-WigglerToggle -KeyboardApi $KeyboardApi
        $script:NextPhase = 'FirstToggle'
        $Timer.Interval = 20000
        return
    }

    # This starts the next cycle after the longer wait from the original script.
    Send-WigglerToggle -KeyboardApi $KeyboardApi
    $script:NextPhase = 'SecondToggle'
    $Timer.Interval = 1000
}
