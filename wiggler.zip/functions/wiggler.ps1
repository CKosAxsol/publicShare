Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type @"
using System;
using System.Runtime.InteropServices;

public static class WigglerKeyboardApi
{
    [DllImport("user32.dll", SetLastError = true)]
    public static extern void keybd_event(byte bVk, byte bScan, int dwFlags, UIntPtr dwExtraInfo);
}

public static class WigglerWindowApi
{
    [DllImport("kernel32.dll")]
    public static extern IntPtr GetConsoleWindow();

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
}
"@

. "$PSScriptRoot\WigglerFunctions.ps1"

$script:IsRunning = $false
$script:NextPhase = 'FirstToggle'
$timer = New-Object System.Windows.Forms.Timer

$form = New-Object System.Windows.Forms.Form
$form.Text = 'wiggler'
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.MinimizeBox = $true
$form.ClientSize = New-Object System.Drawing.Size(280, 140)
$form.TopMost = $true
$form.Add_Shown({
    # This hides the PowerShell console after the app window is visible.
    $consoleWindow = [WigglerWindowApi]::GetConsoleWindow()
    if ($consoleWindow -ne [IntPtr]::Zero) {
        [void][WigglerWindowApi]::ShowWindow($consoleWindow, 0)
    }
})

$startButton = New-Object System.Windows.Forms.Button
$startButton.Text = 'start'
$startButton.Size = New-Object System.Drawing.Size(100, 36)
$startButton.Location = New-Object System.Drawing.Point(24, 24)

$stopButton = New-Object System.Windows.Forms.Button
$stopButton.Text = 'stop'
$stopButton.Size = New-Object System.Drawing.Size(100, 36)
$stopButton.Location = New-Object System.Drawing.Point(148, 24)
$stopButton.Enabled = $false

$statusCaption = New-Object System.Windows.Forms.Label
$statusCaption.Text = 'Status:'
$statusCaption.AutoSize = $true
$statusCaption.Location = New-Object System.Drawing.Point(24, 88)

$statusValue = New-Object System.Windows.Forms.Label
$statusValue.AutoSize = $true
$statusValue.Location = New-Object System.Drawing.Point(76, 88)
$statusValue.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)

Set-WigglerStatus -StatusLabel $statusValue -IsRunning $false

$startButton.Add_Click({
    Start-WigglerLoop -KeyboardApi ([WigglerKeyboardApi]) -Timer $timer -StatusLabel $statusValue -StartButton $startButton -StopButton $stopButton
})

$stopButton.Add_Click({
    Stop-WigglerLoop -Timer $timer -StatusLabel $statusValue -StartButton $startButton -StopButton $stopButton
})

$timer.Add_Tick({
    Step-WigglerLoop -KeyboardApi ([WigglerKeyboardApi]) -Timer $timer
})

$form.Add_FormClosing({
    Stop-WigglerLoop -Timer $timer -StatusLabel $statusValue -StartButton $startButton -StopButton $stopButton
})

$form.Controls.Add($startButton)
$form.Controls.Add($stopButton)
$form.Controls.Add($statusCaption)
$form.Controls.Add($statusValue)

[void]$form.ShowDialog()
$timer.Dispose()
$form.Dispose()
exit
